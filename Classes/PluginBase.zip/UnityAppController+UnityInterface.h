#pragma once

#include "UnityAppController.h"


@interface UnityAppController (UnityInterface)

@property (nonatomic) BOOL  paused;

@end
